/**
 * Basketball Team Tracker - Statistics Management
 * Handles player statistics calculations and team performance metrics
 */

class StatsManager {
    constructor(storageManager) {
        this.storage = storageManager;
    }

    /**
     * Calculate individual player statistics
     */
    calculatePlayerStats(playerId) {
        const playerStats = this.storage.getPlayerStatsByPlayerId(playerId);
        
        if (playerStats.length === 0) {
            return this.getEmptyPlayerStats();
        }

        const totals = {
            games: playerStats.length,
            points: 0,
            rebounds: 0,
            assists: 0,
            steals: 0,
            blocks: 0,
            turnovers: 0,
            minutesPlayed: 0
        };

        // Calculate totals
        playerStats.forEach(stat => {
            totals.points += parseInt(stat.points) || 0;
            totals.rebounds += parseInt(stat.rebounds) || 0;
            totals.assists += parseInt(stat.assists) || 0;
            totals.steals += parseInt(stat.steals) || 0;
            totals.blocks += parseInt(stat.blocks) || 0;
            totals.turnovers += parseInt(stat.turnovers) || 0;
            totals.minutesPlayed += parseInt(stat.minutesPlayed) || 0;
        });

        // Calculate averages
        const averages = {
            pointsPerGame: this.roundToDecimal(totals.points / totals.games, 1),
            reboundsPerGame: this.roundToDecimal(totals.rebounds / totals.games, 1),
            assistsPerGame: this.roundToDecimal(totals.assists / totals.games, 1),
            stealsPerGame: this.roundToDecimal(totals.steals / totals.games, 1),
            blocksPerGame: this.roundToDecimal(totals.blocks / totals.games, 1),
            turnoversPerGame: this.roundToDecimal(totals.turnovers / totals.games, 1),
            minutesPerGame: this.roundToDecimal(totals.minutesPlayed / totals.games, 1)
        };

        // Calculate advanced stats
        const advanced = {
            assistToTurnoverRatio: totals.turnovers > 0 ? 
                this.roundToDecimal(totals.assists / totals.turnovers, 2) : totals.assists,
            efficiency: this.calculatePlayerEfficiency(totals),
            doubleDoubles: this.countDoubleDoubles(playerStats),
            tripleDoubles: this.countTripleDoubles(playerStats)
        };

        return {
            totals,
            averages,
            advanced,
            games: totals.games
        };
    }

    /**
     * Calculate player efficiency rating
     */
    calculatePlayerEfficiency(totals) {
        // Simplified efficiency formula: (Points + Rebounds + Assists + Steals + Blocks - Turnovers) / Games
        const efficiency = (totals.points + totals.rebounds + totals.assists + 
                          totals.steals + totals.blocks - totals.turnovers) / totals.games;
        return this.roundToDecimal(efficiency, 1);
    }

    /**
     * Count double-doubles for a player
     */
    countDoubleDoubles(playerStats) {
        return playerStats.filter(stat => {
            const categories = [
                parseInt(stat.points) || 0,
                parseInt(stat.rebounds) || 0,
                parseInt(stat.assists) || 0,
                parseInt(stat.steals) || 0,
                parseInt(stat.blocks) || 0
            ];
            
            const doubleDigitCategories = categories.filter(value => value >= 10);
            return doubleDigitCategories.length >= 2;
        }).length;
    }

    /**
     * Count triple-doubles for a player
     */
    countTripleDoubles(playerStats) {
        return playerStats.filter(stat => {
            const categories = [
                parseInt(stat.points) || 0,
                parseInt(stat.rebounds) || 0,
                parseInt(stat.assists) || 0,
                parseInt(stat.steals) || 0,
                parseInt(stat.blocks) || 0
            ];
            
            const doubleDigitCategories = categories.filter(value => value >= 10);
            return doubleDigitCategories.length >= 3;
        }).length;
    }

    /**
     * Get empty player stats structure
     */
    getEmptyPlayerStats() {
        return {
            totals: {
                games: 0,
                points: 0,
                rebounds: 0,
                assists: 0,
                steals: 0,
                blocks: 0,
                turnovers: 0,
                minutesPlayed: 0
            },
            averages: {
                pointsPerGame: 0,
                reboundsPerGame: 0,
                assistsPerGame: 0,
                stealsPerGame: 0,
                blocksPerGame: 0,
                turnoversPerGame: 0,
                minutesPerGame: 0
            },
            advanced: {
                assistToTurnoverRatio: 0,
                efficiency: 0,
                doubleDoubles: 0,
                tripleDoubles: 0
            },
            games: 0
        };
    }

    /**
     * Calculate team statistics
     */
    calculateTeamStats() {
        const players = this.storage.getPlayers();
        const games = this.storage.getGames();
        
        if (players.length === 0) {
            return this.getEmptyTeamStats();
        }

        let teamTotals = {
            games: games.length,
            wins: 0,
            losses: 0,
            points: 0,
            rebounds: 0,
            assists: 0,
            steals: 0,
            blocks: 0,
            turnovers: 0
        };

        // Calculate team record from games
        games.forEach(game => {
            const ourScore = parseInt(game.ourScore) || 0;
            const opponentScore = parseInt(game.opponentScore) || 0;
            
            if (ourScore > opponentScore) {
                teamTotals.wins++;
            } else {
                teamTotals.losses++;
            }
        });

        // Calculate team stats from player stats
        players.forEach(player => {
            const playerStats = this.storage.getPlayerStatsByPlayerId(player.id);
            playerStats.forEach(stat => {
                teamTotals.points += parseInt(stat.points) || 0;
                teamTotals.rebounds += parseInt(stat.rebounds) || 0;
                teamTotals.assists += parseInt(stat.assists) || 0;
                teamTotals.steals += parseInt(stat.steals) || 0;
                teamTotals.blocks += parseInt(stat.blocks) || 0;
                teamTotals.turnovers += parseInt(stat.turnovers) || 0;
            });
        });

        // Calculate averages per game
        const gamesPlayed = teamTotals.games > 0 ? teamTotals.games : 1;
        const averages = {
            pointsPerGame: this.roundToDecimal(teamTotals.points / gamesPlayed, 1),
            reboundsPerGame: this.roundToDecimal(teamTotals.rebounds / gamesPlayed, 1),
            assistsPerGame: this.roundToDecimal(teamTotals.assists / gamesPlayed, 1),
            stealsPerGame: this.roundToDecimal(teamTotals.steals / gamesPlayed, 1),
            blocksPerGame: this.roundToDecimal(teamTotals.blocks / gamesPlayed, 1),
            turnoversPerGame: this.roundToDecimal(teamTotals.turnovers / gamesPlayed, 1)
        };

        // Calculate win percentage
        const winPercentage = teamTotals.games > 0 ? 
            this.roundToDecimal((teamTotals.wins / teamTotals.games) * 100, 1) : 0;

        return {
            record: {
                wins: teamTotals.wins,
                losses: teamTotals.losses,
                winPercentage: winPercentage,
                games: teamTotals.games
            },
            totals: {
                points: teamTotals.points,
                rebounds: teamTotals.rebounds,
                assists: teamTotals.assists,
                steals: teamTotals.steals,
                blocks: teamTotals.blocks,
                turnovers: teamTotals.turnovers
            },
            averages: averages
        };
    }

    /**
     * Get empty team stats structure
     */
    getEmptyTeamStats() {
        return {
            record: {
                wins: 0,
                losses: 0,
                winPercentage: 0,
                games: 0
            },
            totals: {
                points: 0,
                rebounds: 0,
                assists: 0,
                steals: 0,
                blocks: 0,
                turnovers: 0
            },
            averages: {
                pointsPerGame: 0,
                reboundsPerGame: 0,
                assistsPerGame: 0,
                stealsPerGame: 0,
                blocksPerGame: 0,
                turnoversPerGame: 0
            }
        };
    }

    /**
     * Get top performers in various categories
     */
    getTopPerformers() {
        const players = this.storage.getPlayers();
        const topPerformers = {
            points: { player: null, value: 0 },
            rebounds: { player: null, value: 0 },
            assists: { player: null, value: 0 },
            steals: { player: null, value: 0 },
            blocks: { player: null, value: 0 },
            efficiency: { player: null, value: 0 }
        };

        players.forEach(player => {
            const stats = this.calculatePlayerStats(player.id);
            
            if (stats.games > 0) {
                // Check points per game
                if (stats.averages.pointsPerGame > topPerformers.points.value) {
                    topPerformers.points = {
                        player: player,
                        value: stats.averages.pointsPerGame
                    };
                }
                
                // Check rebounds per game
                if (stats.averages.reboundsPerGame > topPerformers.rebounds.value) {
                    topPerformers.rebounds = {
                        player: player,
                        value: stats.averages.reboundsPerGame
                    };
                }
                
                // Check assists per game
                if (stats.averages.assistsPerGame > topPerformers.assists.value) {
                    topPerformers.assists = {
                        player: player,
                        value: stats.averages.assistsPerGame
                    };
                }
                
                // Check steals per game
                if (stats.averages.stealsPerGame > topPerformers.steals.value) {
                    topPerformers.steals = {
                        player: player,
                        value: stats.averages.stealsPerGame
                    };
                }
                
                // Check blocks per game
                if (stats.averages.blocksPerGame > topPerformers.blocks.value) {
                    topPerformers.blocks = {
                        player: player,
                        value: stats.averages.blocksPerGame
                    };
                }
                
                // Check efficiency
                if (stats.advanced.efficiency > topPerformers.efficiency.value) {
                    topPerformers.efficiency = {
                        player: player,
                        value: stats.advanced.efficiency
                    };
                }
            }
        });

        return topPerformers;
    }

    /**
     * Get player rankings by category
     */
    getPlayerRankings(category = 'points') {
        const players = this.storage.getPlayers();
        const rankings = [];

        players.forEach(player => {
            const stats = this.calculatePlayerStats(player.id);
            if (stats.games > 0) {
                let value = 0;
                
                switch (category) {
                    case 'points':
                        value = stats.averages.pointsPerGame;
                        break;
                    case 'rebounds':
                        value = stats.averages.reboundsPerGame;
                        break;
                    case 'assists':
                        value = stats.averages.assistsPerGame;
                        break;
                    case 'steals':
                        value = stats.averages.stealsPerGame;
                        break;
                    case 'blocks':
                        value = stats.averages.blocksPerGame;
                        break;
                    case 'efficiency':
                        value = stats.advanced.efficiency;
                        break;
                    default:
                        value = stats.averages.pointsPerGame;
                }
                
                rankings.push({
                    player: player,
                    value: value,
                    stats: stats
                });
            }
        });

        // Sort by value (descending)
        rankings.sort((a, b) => b.value - a.value);
        
        // Add rank
        rankings.forEach((item, index) => {
            item.rank = index + 1;
        });

        return rankings;
    }

    /**
     * Get recent performance trends
     */
    getPerformanceTrends(playerId, games = 5) {
        const playerStats = this.storage.getPlayerStatsByPlayerId(playerId);
        
        if (playerStats.length === 0) {
            return [];
        }

        // Sort by date (most recent first) and take last N games
        const recentStats = playerStats
            .sort((a, b) => new Date(b.date) - new Date(a.date))
            .slice(0, games);

        return recentStats.map(stat => ({
            date: stat.date,
            points: parseInt(stat.points) || 0,
            rebounds: parseInt(stat.rebounds) || 0,
            assists: parseInt(stat.assists) || 0,
            efficiency: this.calculateGameEfficiency(stat)
        }));
    }

    /**
     * Calculate efficiency for a single game
     */
    calculateGameEfficiency(stat) {
        const points = parseInt(stat.points) || 0;
        const rebounds = parseInt(stat.rebounds) || 0;
        const assists = parseInt(stat.assists) || 0;
        const steals = parseInt(stat.steals) || 0;
        const blocks = parseInt(stat.blocks) || 0;
        const turnovers = parseInt(stat.turnovers) || 0;
        
        return this.roundToDecimal(points + rebounds + assists + steals + blocks - turnovers, 1);
    }

    /**
     * Get season comparison data
     */
    getSeasonComparison() {
        const games = this.storage.getGames();
        
        // Group games by year
        const gamesByYear = {};
        games.forEach(game => {
            const year = new Date(game.date).getFullYear();
            if (!gamesByYear[year]) {
                gamesByYear[year] = [];
            }
            gamesByYear[year].push(game);
        });

        // Calculate stats for each year
        const yearlyStats = {};
        Object.keys(gamesByYear).forEach(year => {
            const yearGames = gamesByYear[year];
            let wins = 0;
            let losses = 0;
            
            yearGames.forEach(game => {
                const ourScore = parseInt(game.ourScore) || 0;
                const opponentScore = parseInt(game.opponentScore) || 0;
                
                if (ourScore > opponentScore) {
                    wins++;
                } else {
                    losses++;
                }
            });
            
            yearlyStats[year] = {
                wins: wins,
                losses: losses,
                games: yearGames.length,
                winPercentage: yearGames.length > 0 ? 
                    this.roundToDecimal((wins / yearGames.length) * 100, 1) : 0
            };
        });

        return yearlyStats;
    }

    /**
     * Validate stat entry
     */
    validateStatEntry(stat) {
        const errors = [];
        
        if (!stat.playerId) {
            errors.push('Player is required');
        }
        
        if (!stat.date) {
            errors.push('Date is required');
        }
        
        // Validate numeric fields
        const numericFields = ['points', 'rebounds', 'assists', 'steals', 'blocks', 'turnovers', 'minutesPlayed'];
        numericFields.forEach(field => {
            if (stat[field] !== undefined && stat[field] !== '') {
                const value = parseInt(stat[field]);
                if (isNaN(value) || value < 0) {
                    errors.push(`${field} must be a non-negative number`);
                }
                if (field === 'minutesPlayed' && value > 48) {
                    errors.push('Minutes played cannot exceed 48 minutes');
                }
            }
        });
        
        return {
            isValid: errors.length === 0,
            errors: errors
        };
    }

    /**
     * Export player statistics to CSV format
     */
    exportPlayerStatsToCSV(playerId) {
        const player = this.storage.getPlayerById(playerId);
        const playerStats = this.storage.getPlayerStatsByPlayerId(playerId);
        
        if (!player || playerStats.length === 0) {
            return null;
        }

        const headers = ['Date', 'Points', 'Rebounds', 'Assists', 'Steals', 'Blocks', 'Turnovers', 'Minutes'];
        const csvContent = [
            `Player: ${player.name} (#${player.jerseyNumber})`,
            '',
            headers.join(','),
            ...playerStats.map(stat => [
                stat.date,
                stat.points || 0,
                stat.rebounds || 0,
                stat.assists || 0,
                stat.steals || 0,
                stat.blocks || 0,
                stat.turnovers || 0,
                stat.minutesPlayed || 0
            ].join(','))
        ].join('\n');

        return csvContent;
    }

    /**
     * Export team statistics to CSV format
     */
    exportTeamStatsToCSV() {
        const players = this.storage.getPlayers();
        const headers = ['Player', 'Jersey', 'Position', 'Games', 'PPG', 'RPG', 'APG', 'SPG', 'BPG', 'TPG', 'Efficiency'];
        
        const csvContent = [
            'Team Statistics Summary',
            '',
            headers.join(','),
            ...players.map(player => {
                const stats = this.calculatePlayerStats(player.id);
                return [
                    player.name,
                    player.jerseyNumber,
                    player.position,
                    stats.games,
                    stats.averages.pointsPerGame,
                    stats.averages.reboundsPerGame,
                    stats.averages.assistsPerGame,
                    stats.averages.stealsPerGame,
                    stats.averages.blocksPerGame,
                    stats.averages.turnoversPerGame,
                    stats.advanced.efficiency
                ].join(',');
            })
        ].join('\n');

        return csvContent;
    }

    /**
     * Utility method to round numbers to specified decimal places
     */
    roundToDecimal(number, decimals) {
        return Math.round(number * Math.pow(10, decimals)) / Math.pow(10, decimals);
    }

    /**
     * Format statistics for display
     */
    formatStatForDisplay(value, type = 'number') {
        if (value === null || value === undefined) {
            return '0';
        }
        
        switch (type) {
            case 'percentage':
                return `${value}%`;
            case 'ratio':
                return value.toFixed(2);
            case 'average':
                return value.toFixed(1);
            default:
                return value.toString();
        }
    }
}

// Create global stats manager instance
window.statsManager = new StatsManager(window.storageManager);