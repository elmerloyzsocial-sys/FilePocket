/**
 * Basketball Team Tracker - Calendar Management
 * Handles calendar display, event scheduling, and date management
 */

class CalendarManager {
    constructor(storageManager) {
        this.storage = storageManager;
        this.currentDate = new Date();
        this.selectedDate = null;
        this.monthNames = [
            'January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'
        ];
        this.dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        
        this.initializeCalendar();
    }

    /**
     * Initialize calendar functionality
     */
    initializeCalendar() {
        this.setupEventListeners();
        this.renderCalendar();
        this.updateUpcomingEvents();
    }

    /**
     * Setup event listeners for calendar controls
     */
    setupEventListeners() {
        // Month navigation
        const prevMonthBtn = document.getElementById('prev-month');
        const nextMonthBtn = document.getElementById('next-month');
        
        if (prevMonthBtn) {
            prevMonthBtn.addEventListener('click', () => {
                this.previousMonth();
            });
        }
        
        if (nextMonthBtn) {
            nextMonthBtn.addEventListener('click', () => {
                this.nextMonth();
            });
        }

        // Calendar form submission
        const calendarForm = document.getElementById('calendar-form');
        if (calendarForm) {
            calendarForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleEventSubmission();
            });
        }
    }

    /**
     * Navigate to previous month
     */
    previousMonth() {
        this.currentDate.setMonth(this.currentDate.getMonth() - 1);
        this.renderCalendar();
    }

    /**
     * Navigate to next month
     */
    nextMonth() {
        this.currentDate.setMonth(this.currentDate.getMonth() + 1);
        this.renderCalendar();
    }

    /**
     * Render the calendar grid
     */
    renderCalendar() {
        const calendarGrid = document.getElementById('calendar-grid');
        const currentMonthElement = document.getElementById('current-month');
        
        if (!calendarGrid || !currentMonthElement) return;

        // Update month display
        currentMonthElement.textContent = `${this.monthNames[this.currentDate.getMonth()]} ${this.currentDate.getFullYear()}`;

        // Clear existing calendar
        calendarGrid.innerHTML = '';

        // Add day headers
        this.dayNames.forEach(day => {
            const dayHeader = document.createElement('div');
            dayHeader.className = 'calendar-header-day';
            dayHeader.textContent = day;
            calendarGrid.appendChild(dayHeader);
        });

        // Get first day of month and start date for calendar grid
        const firstDay = new Date(this.currentDate.getFullYear(), this.currentDate.getMonth(), 1);
        const startDate = new Date(firstDay);
        startDate.setDate(startDate.getDate() - firstDay.getDay());

        // Generate calendar days
        const today = new Date();
        const events = this.storage.getCalendarEvents();
        
        for (let i = 0; i < 42; i++) { // 6 weeks * 7 days
            const currentDay = new Date(startDate);
            currentDay.setDate(startDate.getDate() + i);
            
            const dayElement = this.createDayElement(currentDay, today, events);
            calendarGrid.appendChild(dayElement);
        }
    }

    /**
     * Create a calendar day element
     */
    createDayElement(date, today, events) {
        const dayElement = document.createElement('div');
        dayElement.className = 'calendar-day';
        
        // Add classes for styling
        if (date.getMonth() !== this.currentDate.getMonth()) {
            dayElement.classList.add('other-month');
        }
        
        if (this.isSameDay(date, today)) {
            dayElement.classList.add('today');
        }
        
        // Add day number
        const dayNumber = document.createElement('div');
        dayNumber.className = 'day-number font-semibold';
        dayNumber.textContent = date.getDate();
        dayElement.appendChild(dayNumber);
        
        // Add events for this day
        const dayEvents = this.getEventsForDate(date, events);
        if (dayEvents.length > 0) {
            dayElement.classList.add('has-event');
            
            dayEvents.forEach(event => {
                const eventElement = document.createElement('div');
                eventElement.className = `calendar-event ${event.type}`;
                eventElement.textContent = this.truncateText(event.description, 15);
                eventElement.title = `${event.description} at ${event.time}`;
                dayElement.appendChild(eventElement);
            });
        }
        
        // Add click handler
        dayElement.addEventListener('click', () => {
            this.selectDate(date);
        });
        
        return dayElement;
    }

    /**
     * Get events for a specific date
     */
    getEventsForDate(date, events) {
        const dateString = this.formatDateForStorage(date);
        return events.filter(event => event.date === dateString);
    }

    /**
     * Select a date on the calendar
     */
    selectDate(date) {
        // Remove previous selection
        const previousSelected = document.querySelector('.calendar-day.selected');
        if (previousSelected) {
            previousSelected.classList.remove('selected');
        }
        
        // Add selection to clicked day
        const dayElements = document.querySelectorAll('.calendar-day');
        dayElements.forEach(element => {
            const dayNumber = element.querySelector('.day-number');
            if (dayNumber && parseInt(dayNumber.textContent) === date.getDate()) {
                if (date.getMonth() === this.currentDate.getMonth()) {
                    element.classList.add('selected');
                }
            }
        });
        
        this.selectedDate = date;
        
        // Pre-fill form with selected date
        const eventDateInput = document.getElementById('event-date');
        if (eventDateInput) {
            eventDateInput.value = this.formatDateForInput(date);
        }
    }

    /**
     * Handle event form submission
     */
    handleEventSubmission() {
        const form = document.getElementById('calendar-form');
        const eventData = {
            type: document.getElementById('event-type').value,
            date: document.getElementById('event-date').value,
            time: document.getElementById('event-time').value,
            description: document.getElementById('event-description').value,
            location: document.getElementById('event-location').value,
            notes: document.getElementById('event-notes').value
        };
        
        // Validate event data
        const validation = this.validateEvent(eventData);
        if (!validation.isValid) {
            this.showValidationErrors(validation.errors);
            return;
        }
        
        // Save event
        try {
            this.storage.addCalendarEvent(eventData);
            this.showSuccessMessage('Event scheduled successfully!');
            if (form) form.reset();
            this.renderCalendar();
            this.updateUpcomingEvents();
        } catch (error) {
            this.showErrorMessage('Failed to schedule event. Please try again.');
            console.error('Error adding calendar event:', error);
        }
    }

    /**
     * Validate event data
     */
    validateEvent(eventData) {
        const errors = [];
        
        if (!eventData.type) {
            errors.push('Event type is required');
        }
        
        if (!eventData.date) {
            errors.push('Date is required');
        } else {
            const eventDate = new Date(eventData.date);
            if (isNaN(eventDate.getTime())) {
                errors.push('Invalid date format');
            }
        }
        
        if (!eventData.time) {
            errors.push('Time is required');
        }
        
        if (!eventData.description || eventData.description.trim().length === 0) {
            errors.push('Description is required');
        }
        
        if (!eventData.location || eventData.location.trim().length === 0) {
            errors.push('Location is required');
        }
        
        return {
            isValid: errors.length === 0,
            errors: errors
        };
    }

    /**
     * Update upcoming events display
     */
    updateUpcomingEvents() {
        const upcomingEventsContainer = document.getElementById('upcoming-events');
        if (!upcomingEventsContainer) return;
        
        const upcomingEvents = this.storage.getUpcomingEvents(30);
        
        if (upcomingEvents.length === 0) {
            upcomingEventsContainer.innerHTML = '<p class="text-gray-500 text-center py-4">No upcoming events scheduled</p>';
            return;
        }
        
        upcomingEventsContainer.innerHTML = upcomingEvents.map(event => {
            const eventDate = new Date(event.date);
            const formattedDate = this.formatDateForDisplay(eventDate);
            const daysUntil = this.getDaysUntilEvent(eventDate);
            
            return `
                <div class="event-card ${event.type} p-4 border-l-4 rounded-lg shadow-sm">
                    <div class="flex justify-between items-start">
                        <div class="flex-1">
                            <div class="flex items-center gap-2 mb-1">
                                <span class="inline-block w-3 h-3 rounded-full bg-current opacity-75"></span>
                                <span class="font-semibold text-sm uppercase tracking-wide">${event.type}</span>
                            </div>
                            <h4 class="font-semibold text-lg text-gray-900 mb-1">${event.description}</h4>
                            <p class="text-gray-600 text-sm mb-2">
                                <span class="font-medium">${formattedDate}</span> at <span class="font-medium">${event.time}</span>
                            </p>
                            <p class="text-gray-600 text-sm">
                                📍 ${event.location}
                            </p>
                            ${event.notes ? `<p class="text-gray-500 text-sm mt-2">${event.notes}</p>` : ''}
                        </div>
                        <div class="text-right">
                            <div class="text-sm font-medium text-gray-900">${daysUntil}</div>
                            <button onclick="calendarManager.deleteEvent('${event.id}')" 
                                    class="text-red-500 hover:text-red-700 text-sm mt-1">
                                Delete
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }

    /**
     * Delete an event
     */
    deleteEvent(eventId) {
        if (confirm('Are you sure you want to delete this event?')) {
            try {
                this.storage.deleteCalendarEvent(eventId);
                this.showSuccessMessage('Event deleted successfully!');
                this.renderCalendar();
                this.updateUpcomingEvents();
            } catch (error) {
                this.showErrorMessage('Failed to delete event. Please try again.');
                console.error('Error deleting calendar event:', error);
            }
        }
    }

    /**
     * Get days until event
     */
    getDaysUntilEvent(eventDate) {
        const today = new Date();
        const timeDiff = eventDate.getTime() - today.getTime();
        const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
        
        if (daysDiff === 0) {
            return 'Today';
        } else if (daysDiff === 1) {
            return 'Tomorrow';
        } else if (daysDiff > 1) {
            return `In ${daysDiff} days`;
        } else {
            return `${Math.abs(daysDiff)} days ago`;
        }
    }

    /**
     * Get events by type
     */
    getEventsByType(type) {
        const events = this.storage.getCalendarEvents();
        return type === 'all' ? events : events.filter(event => event.type === type);
    }

    /**
     * Get events for date range
     */
    getEventsInRange(startDate, endDate) {
        const events = this.storage.getCalendarEvents();
        return events.filter(event => {
            const eventDate = new Date(event.date);
            return eventDate >= startDate && eventDate <= endDate;
        });
    }

    /**
     * Export calendar events to ICS format
     */
    exportToICS() {
        const events = this.storage.getCalendarEvents();
        
        let icsContent = [
            'BEGIN:VCALENDAR',
            'VERSION:2.0',
            'PRODID:-//Basketball Team Tracker//Calendar//EN',
            'CALSCALE:GREGORIAN'
        ];
        
        events.forEach(event => {
            const eventDate = new Date(event.date + 'T' + event.time);
            const endDate = new Date(eventDate.getTime() + (2 * 60 * 60 * 1000)); // 2 hours later
            
            icsContent.push(
                'BEGIN:VEVENT',
                `UID:${event.id}@basketballtracker.com`,
                `DTSTART:${this.formatDateForICS(eventDate)}`,
                `DTEND:${this.formatDateForICS(endDate)}`,
                `SUMMARY:${event.description}`,
                `DESCRIPTION:${event.notes || ''}`,
                `LOCATION:${event.location}`,
                `CATEGORIES:${event.type.toUpperCase()}`,
                'END:VEVENT'
            );
        });
        
        icsContent.push('END:VCALENDAR');
        
        return icsContent.join('\r\n');
    }

    /**
     * Utility methods
     */
    isSameDay(date1, date2) {
        return date1.getDate() === date2.getDate() &&
               date1.getMonth() === date2.getMonth() &&
               date1.getFullYear() === date2.getFullYear();
    }

    formatDateForStorage(date) {
        return date.toISOString().split('T')[0];
    }

    formatDateForInput(date) {
        return date.toISOString().split('T')[0];
    }

    formatDateForDisplay(date) {
        return date.toLocaleDateString('en-US', {
            weekday: 'short',
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    formatDateForICS(date) {
        return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
    }

    truncateText(text, maxLength) {
        return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
    }

    /**
     * Message display methods
     */
    showSuccessMessage(message) {
        this.showMessage(message, 'success');
    }

    showErrorMessage(message) {
        this.showMessage(message, 'error');
    }

    showValidationErrors(errors) {
        const errorMessage = 'Please fix the following errors:\n' + errors.join('\n');
        alert(errorMessage);
    }

    showMessage(message, type) {
        // Create message element
        const messageElement = document.createElement('div');
        messageElement.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
            type === 'success' ? 'bg-green-100 border border-green-400 text-green-700' : 
            'bg-red-100 border border-red-400 text-red-700'
        }`;
        messageElement.textContent = message;
        
        // Add to page
        document.body.appendChild(messageElement);
        
        // Remove after 3 seconds
        setTimeout(() => {
            if (messageElement.parentNode) {
                messageElement.parentNode.removeChild(messageElement);
            }
        }, 3000);
    }

    /**
     * Get calendar statistics
     */
    getCalendarStats() {
        const events = this.storage.getCalendarEvents();
        const today = new Date();
        
        const stats = {
            total: events.length,
            upcoming: 0,
            past: 0,
            byType: {
                game: 0,
                practice: 0,
                tournament: 0,
                meeting: 0
            }
        };
        
        events.forEach(event => {
            const eventDate = new Date(event.date);
            
            if (eventDate >= today) {
                stats.upcoming++;
            } else {
                stats.past++;
            }
            
            if (Object.prototype.hasOwnProperty.call(stats.byType, event.type)) {
                stats.byType[event.type]++;
            }
        });
        
        return stats;
    }

    /**
     * Search events
     */
    searchEvents(query) {
        const events = this.storage.getCalendarEvents();
        const searchTerm = query.toLowerCase();
        
        return events.filter(event => 
            event.description.toLowerCase().includes(searchTerm) ||
            event.location.toLowerCase().includes(searchTerm) ||
            event.notes.toLowerCase().includes(searchTerm) ||
            event.type.toLowerCase().includes(searchTerm)
        );
    }

    /**
     * Get conflicts for a new event
     */
    getEventConflicts(date, time, duration = 2) {
        const events = this.storage.getCalendarEvents();
        const newEventStart = new Date(date + 'T' + time);
        const newEventEnd = new Date(newEventStart.getTime() + (duration * 60 * 60 * 1000));
        
        return events.filter(event => {
            const existingEventStart = new Date(event.date + 'T' + event.time);
            const existingEventEnd = new Date(existingEventStart.getTime() + (2 * 60 * 60 * 1000));
            
            return (newEventStart < existingEventEnd && newEventEnd > existingEventStart);
        });
    }
}

// Create global calendar manager instance
window.calendarManager = new CalendarManager(window.storageManager);