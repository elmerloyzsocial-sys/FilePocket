/**
 * Basketball Team Tracker - Local Storage Management
 * Handles all data persistence using browser localStorage
 */

class StorageManager {
    constructor() {
        this.keys = {
            GAMES: 'basketball_games',
            PLAYERS: 'basketball_players',
            PLAYER_STATS: 'basketball_player_stats',
            PHOTOS: 'basketball_photos',
            CALENDAR_EVENTS: 'basketball_calendar_events',
            SETTINGS: 'basketball_settings'
        };
        
        // Initialize storage if empty
        this.initializeStorage();
    }

    /**
     * Initialize storage with empty arrays/objects if they don't exist
     */
    initializeStorage() {
        if (!this.getGames()) {
            this.saveGames([]);
        }
        if (!this.getPlayers()) {
            this.savePlayers([]);
        }
        if (!this.getPlayerStats()) {
            this.savePlayerStats({});
        }
        if (!this.getPhotos()) {
            this.savePhotos([]);
        }
        if (!this.getCalendarEvents()) {
            this.saveCalendarEvents([]);
        }
        if (!this.getSettings()) {
            this.saveSettings({
                teamName: 'My Basketball Team',
                season: new Date().getFullYear(),
                theme: 'default'
            });
        }
    }

    /**
     * Generic storage methods
     */
    save(key, data) {
        try {
            localStorage.setItem(key, JSON.stringify(data));
            return true;
        } catch (error) {
            console.error('Error saving to localStorage:', error);
            return false;
        }
    }

    load(key) {
        try {
            const data = localStorage.getItem(key);
            return data ? JSON.parse(data) : null;
        } catch (error) {
            console.error('Error loading from localStorage:', error);
            return null;
        }
    }

    remove(key) {
        try {
            localStorage.removeItem(key);
            return true;
        } catch (error) {
            console.error('Error removing from localStorage:', error);
            return false;
        }
    }

    /**
     * Game-related storage methods
     */
    getGames() {
        return this.load(this.keys.GAMES) || [];
    }

    saveGames(games) {
        return this.save(this.keys.GAMES, games);
    }

    addGame(game) {
        const games = this.getGames();
        game.id = this.generateId();
        game.createdAt = new Date().toISOString();
        games.push(game);
        return this.saveGames(games);
    }

    updateGame(gameId, updatedGame) {
        const games = this.getGames();
        const index = games.findIndex(game => game.id === gameId);
        if (index !== -1) {
            games[index] = { ...games[index], ...updatedGame, updatedAt: new Date().toISOString() };
            return this.saveGames(games);
        }
        return false;
    }

    deleteGame(gameId) {
        const games = this.getGames();
        const filteredGames = games.filter(game => game.id !== gameId);
        return this.saveGames(filteredGames);
    }

    getGameById(gameId) {
        const games = this.getGames();
        return games.find(game => game.id === gameId);
    }

    /**
     * Player-related storage methods
     */
    getPlayers() {
        return this.load(this.keys.PLAYERS) || [];
    }

    savePlayers(players) {
        return this.save(this.keys.PLAYERS, players);
    }

    addPlayer(player) {
        const players = this.getPlayers();
        
        // Check for duplicate jersey numbers
        if (players.some(p => p.jerseyNumber === player.jerseyNumber)) {
            throw new Error('Jersey number already exists');
        }
        
        player.id = this.generateId();
        player.createdAt = new Date().toISOString();
        players.push(player);
        return this.savePlayers(players);
    }

    updatePlayer(playerId, updatedPlayer) {
        const players = this.getPlayers();
        const index = players.findIndex(player => player.id === playerId);
        if (index !== -1) {
            // Check for duplicate jersey numbers (excluding current player)
            if (updatedPlayer.jerseyNumber && 
                players.some(p => p.id !== playerId && p.jerseyNumber === updatedPlayer.jerseyNumber)) {
                throw new Error('Jersey number already exists');
            }
            
            players[index] = { ...players[index], ...updatedPlayer, updatedAt: new Date().toISOString() };
            return this.savePlayers(players);
        }
        return false;
    }

    deletePlayer(playerId) {
        const players = this.getPlayers();
        const filteredPlayers = players.filter(player => player.id !== playerId);
        
        // Also remove player stats
        const playerStats = this.getPlayerStats();
        delete playerStats[playerId];
        this.savePlayerStats(playerStats);
        
        return this.savePlayers(filteredPlayers);
    }

    getPlayerById(playerId) {
        const players = this.getPlayers();
        return players.find(player => player.id === playerId);
    }

    /**
     * Player statistics storage methods
     */
    getPlayerStats() {
        return this.load(this.keys.PLAYER_STATS) || {};
    }

    savePlayerStats(stats) {
        return this.save(this.keys.PLAYER_STATS, stats);
    }

    addPlayerStat(playerId, stat) {
        const playerStats = this.getPlayerStats();
        
        if (!playerStats[playerId]) {
            playerStats[playerId] = [];
        }
        
        stat.id = this.generateId();
        stat.createdAt = new Date().toISOString();
        playerStats[playerId].push(stat);
        
        return this.savePlayerStats(playerStats);
    }

    getPlayerStatsByPlayerId(playerId) {
        const playerStats = this.getPlayerStats();
        return playerStats[playerId] || [];
    }

    updatePlayerStat(playerId, statId, updatedStat) {
        const playerStats = this.getPlayerStats();
        
        if (playerStats[playerId]) {
            const index = playerStats[playerId].findIndex(stat => stat.id === statId);
            if (index !== -1) {
                playerStats[playerId][index] = { 
                    ...playerStats[playerId][index], 
                    ...updatedStat, 
                    updatedAt: new Date().toISOString() 
                };
                return this.savePlayerStats(playerStats);
            }
        }
        return false;
    }

    deletePlayerStat(playerId, statId) {
        const playerStats = this.getPlayerStats();
        
        if (playerStats[playerId]) {
            playerStats[playerId] = playerStats[playerId].filter(stat => stat.id !== statId);
            return this.savePlayerStats(playerStats);
        }
        return false;
    }

    /**
     * Photo storage methods
     */
    getPhotos() {
        return this.load(this.keys.PHOTOS) || [];
    }

    savePhotos(photos) {
        return this.save(this.keys.PHOTOS, photos);
    }

    addPhoto(photo) {
        const photos = this.getPhotos();
        photo.id = this.generateId();
        photo.createdAt = new Date().toISOString();
        photos.push(photo);
        return this.savePhotos(photos);
    }

    updatePhoto(photoId, updatedPhoto) {
        const photos = this.getPhotos();
        const index = photos.findIndex(photo => photo.id === photoId);
        if (index !== -1) {
            photos[index] = { ...photos[index], ...updatedPhoto, updatedAt: new Date().toISOString() };
            return this.savePhotos(photos);
        }
        return false;
    }

    deletePhoto(photoId) {
        const photos = this.getPhotos();
        const filteredPhotos = photos.filter(photo => photo.id !== photoId);
        return this.savePhotos(filteredPhotos);
    }

    getPhotoById(photoId) {
        const photos = this.getPhotos();
        return photos.find(photo => photo.id === photoId);
    }

    getPhotosByCategory(category) {
        const photos = this.getPhotos();
        return category === 'all' ? photos : photos.filter(photo => photo.category === category);
    }

    /**
     * Calendar events storage methods
     */
    getCalendarEvents() {
        return this.load(this.keys.CALENDAR_EVENTS) || [];
    }

    saveCalendarEvents(events) {
        return this.save(this.keys.CALENDAR_EVENTS, events);
    }

    addCalendarEvent(event) {
        const events = this.getCalendarEvents();
        event.id = this.generateId();
        event.createdAt = new Date().toISOString();
        events.push(event);
        return this.saveCalendarEvents(events);
    }

    updateCalendarEvent(eventId, updatedEvent) {
        const events = this.getCalendarEvents();
        const index = events.findIndex(event => event.id === eventId);
        if (index !== -1) {
            events[index] = { ...events[index], ...updatedEvent, updatedAt: new Date().toISOString() };
            return this.saveCalendarEvents(events);
        }
        return false;
    }

    deleteCalendarEvent(eventId) {
        const events = this.getCalendarEvents();
        const filteredEvents = events.filter(event => event.id !== eventId);
        return this.saveCalendarEvents(filteredEvents);
    }

    getCalendarEventById(eventId) {
        const events = this.getCalendarEvents();
        return events.find(event => event.id === eventId);
    }

    getEventsByDate(date) {
        const events = this.getCalendarEvents();
        return events.filter(event => event.date === date);
    }

    getUpcomingEvents(days = 30) {
        const events = this.getCalendarEvents();
        const today = new Date();
        const futureDate = new Date();
        futureDate.setDate(today.getDate() + days);
        
        return events.filter(event => {
            const eventDate = new Date(event.date);
            return eventDate >= today && eventDate <= futureDate;
        }).sort((a, b) => new Date(a.date) - new Date(b.date));
    }

    /**
     * Settings storage methods
     */
    getSettings() {
        return this.load(this.keys.SETTINGS) || {};
    }

    saveSettings(settings) {
        return this.save(this.keys.SETTINGS, settings);
    }

    updateSettings(newSettings) {
        const currentSettings = this.getSettings();
        const updatedSettings = { ...currentSettings, ...newSettings };
        return this.saveSettings(updatedSettings);
    }

    /**
     * Utility methods
     */
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    /**
     * Data export/import methods
     */
    exportAllData() {
        return {
            games: this.getGames(),
            players: this.getPlayers(),
            playerStats: this.getPlayerStats(),
            photos: this.getPhotos(),
            calendarEvents: this.getCalendarEvents(),
            settings: this.getSettings(),
            exportDate: new Date().toISOString()
        };
    }

    importAllData(data) {
        try {
            if (data.games) this.saveGames(data.games);
            if (data.players) this.savePlayers(data.players);
            if (data.playerStats) this.savePlayerStats(data.playerStats);
            if (data.photos) this.savePhotos(data.photos);
            if (data.calendarEvents) this.saveCalendarEvents(data.calendarEvents);
            if (data.settings) this.saveSettings(data.settings);
            return true;
        } catch (error) {
            console.error('Error importing data:', error);
            return false;
        }
    }

    /**
     * Clear all data (use with caution)
     */
    clearAllData() {
        Object.values(this.keys).forEach(key => {
            this.remove(key);
        });
        this.initializeStorage();
    }

    /**
     * Get storage usage information
     */
    getStorageInfo() {
        let totalSize = 0;
        const info = {};
        
        Object.entries(this.keys).forEach(([name, key]) => {
            const data = localStorage.getItem(key);
            const size = data ? new Blob([data]).size : 0;
            info[name] = {
                size: size,
                sizeFormatted: this.formatBytes(size),
                itemCount: this.getItemCount(key)
            };
            totalSize += size;
        });
        
        return {
            ...info,
            total: {
                size: totalSize,
                sizeFormatted: this.formatBytes(totalSize)
            }
        };
    }

    getItemCount(key) {
        const data = this.load(key);
        if (Array.isArray(data)) {
            return data.length;
        } else if (typeof data === 'object' && data !== null) {
            return Object.keys(data).length;
        }
        return 0;
    }

    formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
}

// Create global storage manager instance
window.storageManager = new StorageManager();