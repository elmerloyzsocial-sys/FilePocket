/**
 * Basketball Team Tracker - Main Application Logic
 * Handles navigation, form submissions, photo gallery, and UI interactions
 */

class BasketballTracker {
    constructor() {
        this.currentSection = 'dashboard';
        this.photoFiles = new Map(); // Store photo files temporarily
        
        this.initializeApp();
    }

    /**
     * Initialize the application
     */
    initializeApp() {
        this.setupEventListeners();
        this.setupPhotoGallery();
        this.loadDashboardData();
        this.showSection('dashboard');
        this.setupSearch();
        this.setupMobileMenu();
    }

    /**
     * Setup all event listeners
     */
    setupEventListeners() {
        // Game form submission
        const gameForm = document.getElementById('game-form');
        if (gameForm) {
            gameForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleGameSubmission();
            });
        }

        // Player form submission
        const playerForm = document.getElementById('player-form');
        if (playerForm) {
            playerForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handlePlayerSubmission();
            });
        }

        // Stats form submission
        const statsForm = document.getElementById('stats-form');
        if (statsForm) {
            statsForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleStatsSubmission();
            });
        }

        // Photo input change
        const photoInput = document.getElementById('photo-input');
        if (photoInput) {
            photoInput.addEventListener('change', (e) => {
                this.handlePhotoSelection(e.target.files);
            });
        }

        // Gallery filter
        const galleryFilter = document.getElementById('gallery-filter');
        if (galleryFilter) {
            galleryFilter.addEventListener('change', (e) => {
                this.filterPhotos(e.target.value);
            });
        }

        // Search functionality
        const coachingSearch = document.getElementById('coaching-search');
        if (coachingSearch) {
            coachingSearch.addEventListener('input', (e) => {
                this.searchCoachingAdvice(e.target.value);
            });
        }

        const playsSearch = document.getElementById('plays-search');
        if (playsSearch) {
            playsSearch.addEventListener('input', (e) => {
                this.searchPlays(e.target.value);
            });
        }

        const playsFilter = document.getElementById('plays-filter');
        if (playsFilter) {
            playsFilter.addEventListener('change', (e) => {
                this.filterPlays(e.target.value);
            });
        }
    }

    /**
     * Setup mobile menu functionality
     */
    setupMobileMenu() {
        const mobileMenuBtn = document.getElementById('mobile-menu-btn');
        const mobileMenu = document.getElementById('mobile-menu');
        
        if (mobileMenuBtn && mobileMenu) {
            mobileMenuBtn.addEventListener('click', () => {
                mobileMenu.classList.toggle('hidden');
            });
        }
    }

    /**
     * Show specific section and hide others
     */
    showSection(sectionId) {
        // Hide all sections
        const sections = document.querySelectorAll('.section');
        sections.forEach(section => {
            section.classList.remove('active');
        });

        // Show selected section
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');
            this.currentSection = sectionId;
        }

        // Update navigation
        this.updateNavigation(sectionId);

        // Load section-specific data
        this.loadSectionData(sectionId);

        // Hide mobile menu
        const mobileMenu = document.getElementById('mobile-menu');
        if (mobileMenu) {
            mobileMenu.classList.add('hidden');
        }
    }

    /**
     * Update navigation active states
     */
    updateNavigation(activeSection) {
        const navButtons = document.querySelectorAll('.nav-btn');
        navButtons.forEach(btn => {
            btn.classList.remove('active');
        });

        // Add active class to current section button
        const activeBtn = document.querySelector(`[onclick="showSection('${activeSection}')"]`);
        if (activeBtn) {
            activeBtn.classList.add('active');
        }
    }

    /**
     * Load section-specific data
     */
    loadSectionData(sectionId) {
        switch (sectionId) {
            case 'dashboard':
                this.loadDashboardData();
                break;
            case 'team-records':
                this.loadTeamRecords();
                break;
            case 'player-stats':
                this.loadPlayerStats();
                break;
            case 'photo-gallery':
                this.loadPhotoGallery();
                break;
            case 'game-calendar':
                // Calendar is handled by CalendarManager
                break;
            case 'coaching-advice':
                // Static content, no loading needed
                break;
            case 'basketball-plays':
                // Static content, no loading needed
                break;
        }
    }

    /**
     * Load dashboard data
     */
    loadDashboardData() {
        const teamStats = window.statsManager.calculateTeamStats();
        const players = window.storageManager.getPlayers();
        const upcomingEvents = window.storageManager.getUpcomingEvents(30);

        // Update season record
        const seasonRecord = document.getElementById('season-record');
        if (seasonRecord) {
            seasonRecord.textContent = `${teamStats.record.wins}-${teamStats.record.losses}`;
        }

        // Update active players count
        const activePlayers = document.getElementById('active-players');
        if (activePlayers) {
            activePlayers.textContent = players.length;
        }

        // Update upcoming games count
        const upcomingGames = document.getElementById('upcoming-games');
        if (upcomingGames) {
            const gameEvents = upcomingEvents.filter(event => event.type === 'game');
            upcomingGames.textContent = gameEvents.length;
        }
    }

    /**
     * Handle game form submission
     */
    handleGameSubmission() {
        const gameData = {
            date: document.getElementById('game-date').value,
            opponent: document.getElementById('opponent').value,
            location: document.getElementById('location').value,
            ourScore: parseInt(document.getElementById('our-score').value),
            opponentScore: parseInt(document.getElementById('opponent-score').value),
            notes: document.getElementById('game-notes').value
        };

        // Validate game data
        if (!this.validateGameData(gameData)) {
            return;
        }

        try {
            window.storageManager.addGame(gameData);
            this.showSuccessMessage('Game result added successfully!');
            document.getElementById('game-form').reset();
            this.loadTeamRecords();
            this.loadDashboardData();
        } catch (error) {
            this.showErrorMessage('Failed to add game result. Please try again.');
            console.error('Error adding game:', error);
        }
    }

    /**
     * Validate game data
     */
    validateGameData(gameData) {
        if (!gameData.date) {
            this.showErrorMessage('Game date is required');
            return false;
        }
        if (!gameData.opponent.trim()) {
            this.showErrorMessage('Opponent name is required');
            return false;
        }
        if (!gameData.location) {
            this.showErrorMessage('Game location is required');
            return false;
        }
        if (isNaN(gameData.ourScore) || gameData.ourScore < 0) {
            this.showErrorMessage('Valid score is required');
            return false;
        }
        if (isNaN(gameData.opponentScore) || gameData.opponentScore < 0) {
            this.showErrorMessage('Valid opponent score is required');
            return false;
        }
        return true;
    }

    /**
     * Load team records table
     */
    loadTeamRecords() {
        const games = window.storageManager.getGames();
        const tableBody = document.getElementById('games-table-body');
        
        if (!tableBody) return;

        if (games.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-gray-500">No games recorded yet</td></tr>';
            return;
        }

        // Sort games by date (most recent first)
        games.sort((a, b) => new Date(b.date) - new Date(a.date));

        tableBody.innerHTML = games.map(game => {
            const result = game.ourScore > game.opponentScore ? 'Win' : 'Loss';
            const resultClass = result === 'Win' ? 'text-green-600 font-semibold' : 'text-red-600 font-semibold';
            const locationIcon = game.location === 'home' ? '🏠' : '✈️';
            
            return `
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${this.formatDate(game.date)}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${game.opponent}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${locationIcon} ${game.location.charAt(0).toUpperCase() + game.location.slice(1)}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${game.ourScore} - ${game.opponentScore}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm ${resultClass}">
                        ${result}
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-900">
                        ${game.notes || '-'}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <button onclick="basketballTracker.deleteGame('${game.id}')" 
                                class="text-red-600 hover:text-red-900">Delete</button>
                    </td>
                </tr>
            `;
        }).join('');
    }

    /**
     * Delete a game
     */
    deleteGame(gameId) {
        if (confirm('Are you sure you want to delete this game?')) {
            try {
                window.storageManager.deleteGame(gameId);
                this.showSuccessMessage('Game deleted successfully!');
                this.loadTeamRecords();
                this.loadDashboardData();
            } catch (error) {
                this.showErrorMessage('Failed to delete game. Please try again.');
                console.error('Error deleting game:', error);
            }
        }
    }

    /**
     * Handle player form submission
     */
    handlePlayerSubmission() {
        const playerData = {
            name: document.getElementById('player-name').value.trim(),
            jerseyNumber: parseInt(document.getElementById('jersey-number').value),
            position: document.getElementById('position').value
        };

        // Validate player data
        if (!this.validatePlayerData(playerData)) {
            return;
        }

        try {
            window.storageManager.addPlayer(playerData);
            this.showSuccessMessage('Player added successfully!');
            document.getElementById('player-form').reset();
            this.loadPlayerStats();
            this.updateStatsPlayerDropdown();
            this.loadDashboardData();
        } catch (error) {
            if (error.message === 'Jersey number already exists') {
                this.showErrorMessage('Jersey number already exists. Please choose a different number.');
            } else {
                this.showErrorMessage('Failed to add player. Please try again.');
            }
            console.error('Error adding player:', error);
        }
    }

    /**
     * Validate player data
     */
    validatePlayerData(playerData) {
        if (!playerData.name) {
            this.showErrorMessage('Player name is required');
            return false;
        }
        if (isNaN(playerData.jerseyNumber) || playerData.jerseyNumber < 0 || playerData.jerseyNumber > 99) {
            this.showErrorMessage('Valid jersey number (0-99) is required');
            return false;
        }
        if (!playerData.position) {
            this.showErrorMessage('Player position is required');
            return false;
        }
        return true;
    }

    /**
     * Handle stats form submission
     */
    handleStatsSubmission() {
        const statsData = {
            playerId: document.getElementById('stats-player').value,
            date: document.getElementById('stats-date').value,
            points: parseInt(document.getElementById('points').value) || 0,
            rebounds: parseInt(document.getElementById('rebounds').value) || 0,
            assists: parseInt(document.getElementById('assists').value) || 0,
            steals: parseInt(document.getElementById('steals').value) || 0,
            blocks: parseInt(document.getElementById('blocks').value) || 0,
            turnovers: parseInt(document.getElementById('turnovers').value) || 0
        };

        // Validate stats data
        const validation = window.statsManager.validateStatEntry(statsData);
        if (!validation.isValid) {
            this.showErrorMessage('Please fix the following errors:\n' + validation.errors.join('\n'));
            return;
        }

        try {
            window.storageManager.addPlayerStat(statsData.playerId, statsData);
            this.showSuccessMessage('Player statistics added successfully!');
            document.getElementById('stats-form').reset();
            this.loadPlayerStats();
        } catch (error) {
            this.showErrorMessage('Failed to add statistics. Please try again.');
            console.error('Error adding player stats:', error);
        }
    }

    /**
     * Load player statistics
     */
    loadPlayerStats() {
        const players = window.storageManager.getPlayers();
        const playersContainer = document.getElementById('players-container');
        
        if (!playersContainer) return;

        if (players.length === 0) {
            playersContainer.innerHTML = '<div class="col-span-full text-center py-8 text-gray-500">No players added yet</div>';
            return;
        }

        playersContainer.innerHTML = players.map(player => {
            const stats = window.statsManager.calculatePlayerStats(player.id);
            
            return `
                <div class="player-card bg-white rounded-lg shadow-md p-6 border-l-4 border-basketball-orange">
                    <div class="flex items-center justify-between mb-4">
                        <div class="player-number bg-basketball-orange text-white w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg">
                            ${player.jerseyNumber}
                        </div>
                        <button onclick="basketballTracker.deletePlayer('${player.id}')" 
                                class="text-red-500 hover:text-red-700 text-sm">Delete</button>
                    </div>
                    
                    <h3 class="text-xl font-semibold text-basketball-dark mb-1">${player.name}</h3>
                    <p class="text-gray-600 mb-4">${player.position}</p>
                    
                    <div class="space-y-2">
                        <div class="stat-item flex justify-between">
                            <span class="stat-label">Games Played</span>
                            <span class="stat-value">${stats.games}</span>
                        </div>
                        <div class="stat-item flex justify-between">
                            <span class="stat-label">Points/Game</span>
                            <span class="stat-value">${stats.averages.pointsPerGame}</span>
                        </div>
                        <div class="stat-item flex justify-between">
                            <span class="stat-label">Rebounds/Game</span>
                            <span class="stat-value">${stats.averages.reboundsPerGame}</span>
                        </div>
                        <div class="stat-item flex justify-between">
                            <span class="stat-label">Assists/Game</span>
                            <span class="stat-value">${stats.averages.assistsPerGame}</span>
                        </div>
                        <div class="stat-item flex justify-between">
                            <span class="stat-label">Efficiency</span>
                            <span class="stat-value">${stats.advanced.efficiency}</span>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        // Update stats player dropdown
        this.updateStatsPlayerDropdown();
    }

    /**
     * Update stats player dropdown
     */
    updateStatsPlayerDropdown() {
        const players = window.storageManager.getPlayers();
        const dropdown = document.getElementById('stats-player');
        
        if (!dropdown) return;

        dropdown.innerHTML = '<option value="">Select Player</option>' + 
            players.map(player => 
                `<option value="${player.id}">${player.name} (#${player.jerseyNumber})</option>`
            ).join('');
    }

    /**
     * Delete a player
     */
    deletePlayer(playerId) {
        if (confirm('Are you sure you want to delete this player? This will also delete all their statistics.')) {
            try {
                window.storageManager.deletePlayer(playerId);
                this.showSuccessMessage('Player deleted successfully!');
                this.loadPlayerStats();
                this.updateStatsPlayerDropdown();
                this.loadDashboardData();
            } catch (error) {
                this.showErrorMessage('Failed to delete player. Please try again.');
                console.error('Error deleting player:', error);
            }
        }
    }

    /**
     * Setup photo gallery functionality
     */
    setupPhotoGallery() {
        const uploadArea = document.getElementById('photo-upload-area');
        const photoInput = document.getElementById('photo-input');
        
        if (uploadArea && photoInput) {
            // Drag and drop functionality
            uploadArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                uploadArea.classList.add('dragover');
            });
            
            uploadArea.addEventListener('dragleave', () => {
                uploadArea.classList.remove('dragover');
            });
            
            uploadArea.addEventListener('drop', (e) => {
                e.preventDefault();
                uploadArea.classList.remove('dragover');
                this.handlePhotoSelection(e.dataTransfer.files);
            });
            
            uploadArea.addEventListener('click', () => {
                photoInput.click();
            });
        }
    }

    /**
     * Handle photo selection
     */
    handlePhotoSelection(files) {
        Array.from(files).forEach(file => {
            if (file.type.startsWith('image/')) {
                this.processPhoto(file);
            }
        });
    }

    /**
     * Process and store photo
     */
    processPhoto(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const photoData = {
                name: file.name,
                data: e.target.result,
                category: document.getElementById('photo-category').value || 'other',
                date: document.getElementById('photo-date').value || new Date().toISOString().split('T')[0],
                caption: document.getElementById('photo-caption').value || file.name,
                size: file.size,
                type: file.type
            };
            
            try {
                window.storageManager.addPhoto(photoData);
                this.showSuccessMessage('Photo uploaded successfully!');
                this.loadPhotoGallery();
                
                // Clear form
                document.getElementById('photo-caption').value = '';
            } catch (error) {
                this.showErrorMessage('Failed to upload photo. Please try again.');
                console.error('Error uploading photo:', error);
            }
        };
        reader.readAsDataURL(file);
    }

    /**
     * Load photo gallery
     */
    loadPhotoGallery() {
        const photos = window.storageManager.getPhotos();
        const photoGrid = document.getElementById('photo-grid');
        
        if (!photoGrid) return;

        if (photos.length === 0) {
            photoGrid.innerHTML = '<div class="col-span-full text-center py-8 text-gray-500">No photos uploaded yet</div>';
            return;
        }

        // Sort photos by date (most recent first)
        photos.sort((a, b) => new Date(b.date) - new Date(a.date));

        photoGrid.innerHTML = photos.map(photo => `
            <div class="photo-item relative rounded-lg overflow-hidden shadow-md cursor-pointer" 
                 onclick="basketballTracker.openPhotoModal('${photo.id}')">
                <img src="${photo.data}" alt="${photo.caption}" class="w-full h-48 object-cover">
                <div class="photo-overlay absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent text-white p-3">
                    <p class="font-semibold text-sm">${photo.caption}</p>
                    <p class="text-xs opacity-75">${this.formatDate(photo.date)} • ${photo.category}</p>
                </div>
                <button onclick="event.stopPropagation(); basketballTracker.deletePhoto('${photo.id}')" 
                        class="absolute top-2 right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs hover:bg-red-600">
                    ×
                </button>
            </div>
        `).join('');
    }

    /**
     * Filter photos by category
     */
    filterPhotos(category) {
        const photos = window.storageManager.getPhotosByCategory(category);
        const photoGrid = document.getElementById('photo-grid');
        
        if (!photoGrid) return;

        if (photos.length === 0) {
            photoGrid.innerHTML = '<div class="col-span-full text-center py-8 text-gray-500">No photos found in this category</div>';
            return;
        }

        // Sort photos by date (most recent first)
        photos.sort((a, b) => new Date(b.date) - new Date(a.date));

        photoGrid.innerHTML = photos.map(photo => `
            <div class="photo-item relative rounded-lg overflow-hidden shadow-md cursor-pointer" 
                 onclick="basketballTracker.openPhotoModal('${photo.id}')">
                <img src="${photo.data}" alt="${photo.caption}" class="w-full h-48 object-cover">
                <div class="photo-overlay absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent text-white p-3">
                    <p class="font-semibold text-sm">${photo.caption}</p>
                    <p class="text-xs opacity-75">${this.formatDate(photo.date)} • ${photo.category}</p>
                </div>
                <button onclick="event.stopPropagation(); basketballTracker.deletePhoto('${photo.id}')" 
                        class="absolute top-2 right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs hover:bg-red-600">
                    ×
                </button>
            </div>
        `).join('');
    }

    /**
     * Open photo modal
     */
    openPhotoModal(photoId) {
        const photo = window.storageManager.getPhotoById(photoId);
        if (!photo) return;

        const modal = document.getElementById('photo-modal');
        const modalPhoto = document.getElementById('modal-photo');
        const modalCaption = document.getElementById('modal-caption');
        const modalDate = document.getElementById('modal-date');
        
        if (modal && modalPhoto && modalCaption && modalDate) {
            modalPhoto.src = photo.data;
            modalPhoto.alt = photo.caption;
            modalCaption.textContent = photo.caption;
            modalDate.textContent = `${this.formatDate(photo.date)} • ${photo.category}`;
            
            modal.classList.remove('hidden');
        }
    }

    /**
     * Close photo modal
     */
    closePhotoModal() {
        const modal = document.getElementById('photo-modal');
        if (modal) {
            modal.classList.add('hidden');
        }
    }

    /**
     * Delete a photo
     */
    deletePhoto(photoId) {
        if (confirm('Are you sure you want to delete this photo?')) {
            try {
                window.storageManager.deletePhoto(photoId);
                this.showSuccessMessage('Photo deleted successfully!');
                this.loadPhotoGallery();
            } catch (error) {
                this.showErrorMessage('Failed to delete photo. Please try again.');
                console.error('Error deleting photo:', error);
            }
        }
    }

    /**
     * Setup search functionality
     */
    setupSearch() {
        // Coaching advice search is handled by searchCoachingAdvice method
        // Plays search is handled by searchPlays method
    }

    /**
     * Search coaching advice
     */
    searchCoachingAdvice(query) {
        const sections = document.querySelectorAll('#coaching-advice .advice-content');
        const searchTerm = query.toLowerCase();
        
        sections.forEach(section => {
            const text = section.textContent.toLowerCase();
            const parentSection = section.closest('.bg-white');
            
            if (searchTerm === '' || text.includes(searchTerm)) {
                parentSection.style.display = 'block';
            } else {
                parentSection.style.display = 'none';
            }
        });
    }

    /**
     * Search plays
     */
    searchPlays(query) {
        const sections = document.querySelectorAll('#basketball-plays .play-card, #basketball-plays [id$="-plays"]');
        const searchTerm = query.toLowerCase();
        
        sections.forEach(section => {
            const text = section.textContent.toLowerCase();
            const parentSection = section.closest('.bg-white');
            
            if (searchTerm === '' || text.includes(searchTerm)) {
                if (parentSection) {
                    parentSection.style.display = 'block';
                }
            } else {
                if (parentSection) {
                    parentSection.style.display = 'none';
                }
            }
        });
    }

    /**
     * Filter plays by category
     */
    filterPlays(category) {
        const sections = document.querySelectorAll('#basketball-plays .bg-white');
        
        sections.forEach(section => {
            const sectionId = section.querySelector('[id$="-plays"]')?.id;
            
            if (category === 'all') {
                section.style.display = 'block';
            } else {
                if (sectionId && sectionId.includes(category)) {
                    section.style.display = 'block';
                } else {
                    section.style.display = 'none';
                }
            }
        });
    }

    /**
     * Toggle expandable sections
     */
    toggleSection(sectionId) {
        const content = document.getElementById(sectionId);
        const icon = document.getElementById(sectionId + '-icon');
        
        if (content && icon) {
            if (content.classList.contains('hidden')) {
                content.classList.remove('hidden');
                icon.textContent = '−';
            } else {
                content.classList.add('hidden');
                icon.textContent = '+';
            }
        }
    }

    /**
     * Utility methods
     */
    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    /**
     * Message display methods
     */
    showSuccessMessage(message) {
        this.showMessage(message, 'success');
    }

    showErrorMessage(message) {
        this.showMessage(message, 'error');
    }

    showMessage(message, type) {
        // Create message element
        const messageElement = document.createElement('div');
        messageElement.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
            type === 'success' ? 'bg-green-100 border border-green-400 text-green-700' : 
            'bg-red-100 border border-red-400 text-red-700'
        }`;
        messageElement.textContent = message;
        
        // Add to page
        document.body.appendChild(messageElement);
        
        // Remove after 3 seconds
        setTimeout(() => {
            if (messageElement.parentNode) {
                messageElement.parentNode.removeChild(messageElement);
            }
        }, 3000);
    }
}

// Global functions for HTML onclick handlers
window.showSection = function(sectionId) {
    window.basketballTracker.showSection(sectionId);
};

window.toggleSection = function(sectionId) {
    window.basketballTracker.toggleSection(sectionId);
};

window.closePhotoModal = function() {
    window.basketballTracker.closePhotoModal();
};

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.basketballTracker = new BasketballTracker();
});